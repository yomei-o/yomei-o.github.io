# Block Blast — C++ / libretro 版（フェーズ2）

HTMLプロトタイプ(`../index.html`)のゲームを C++ に移植し、**libretro互換のC API**でラップしたもの。
同じコアを「Windows単体EXE」「libretroコアDLL(RetroArch用)」「WASM(フェーズ3)」に使えます。

## ファイル構成

| ファイル | 役割 |
|---|---|
| `blockcore.h` / `blockcore.cpp` | ゲーム本体。プラットフォーム非依存（`tick`/`render`/framebuffer）。JS版の移植 |
| `libretro.h` | libretro 最小API（定数値は公式と同じ＝後で公式ヘッダに差し替え可能） |
| `libretro_core.cpp` | `BlockCore` を `retro_*` 関数でラップ |
| `win32_main.cpp` | 最小 Win32 フロントエンド（ウィンドウ表示＋キーボード＋60fpsループ） |
| `CMakeLists.txt` | ビルド設定（EXE と DLL） |

## VisualStudio2022 で開いて実行する

1. VS2022 を起動 → **「ローカル フォルダーを開く」** で この `cpp` フォルダを選ぶ
   （VSが CMake を自動検出して構成します）
2. 上部のツールバーの**起動項目（緑の再生ボタン横）のドロップダウン**で **`blockblast.exe`** を選ぶ
3. **F5**（デバッグ実行）または **Ctrl+F5**（デバッグなし実行）で起動

## コマンドラインでビルドする場合

```
cd cpp
cmake -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
build\Release\blockblast.exe
```

## 操作

| キー | 動作 |
|---|---|
| ← → | 移動 |
| ↑ | 回転 |
| ↓ | ソフトドロップ |
| Space | ハードドロップ |
| R | リスタート |
| Esc | 終了 |

## libretro コア DLL（任意）

`blockblast_libretro.dll` をビルドすると、RetroArch の「コアを読み込む」で動かせます
（コンテンツ不要のコアとして登録済み）。`libretro.h` は最小実装なので、
本格運用時は公式 `libretro.h` に差し替えてください（関数名・定数値は合わせてあります）。

## 設計メモ（フェーズ3=WASMに向けて）

- コアは描画も含めて framebuffer(XRGB8888) に自前で書く＝`video_refresh` でそのまま渡せる。
- 入力は `retro_input_state` のジョイパッド（回転/ハードドロップはラッパ側でエッジ検出）。
- 乱数はシード付き xorshift32 で、JS版と同じ結果を再現。
- 同じ `blockcore.*` + `libretro_core.cpp` を Emscripten でビルドすれば WASM の libretro コアになる。
