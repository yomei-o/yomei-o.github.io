// BlockCore 実装（index.html の BlockCore を C++ に移植）
#include "blockcore.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace {
// 7色（黄/橙/緑/水/紫/赤/青）。消すたびにこの順で循環。index 0 は未使用。
const int COLORS[8][3] = {
    {  0,   0,   0},
    {245, 196,  40}, // 1 黄
    {240, 110,  35}, // 2 橙
    { 70, 195,  70}, // 3 緑
    { 70, 200, 235}, // 4 水
    {165,  75, 205}, // 5 紫
    {225,  55,  55}, // 6 赤
    { 60,  95, 225}, // 7 青
};

// テトロミノ（4x4 内のセル座標）。回転は (x,y)->(3-y,x)。
const int SHAPES[7][4][2] = {
    {{0,1},{1,1},{2,1},{3,1}}, // I
    {{1,0},{2,0},{1,1},{2,1}}, // O
    {{1,0},{0,1},{1,1},{2,1}}, // T
    {{1,0},{2,0},{0,1},{1,1}}, // S
    {{0,0},{1,0},{1,1},{2,1}}, // Z
    {{0,0},{0,1},{1,1},{2,1}}, // J
    {{2,0},{0,1},{1,1},{2,1}}, // L
};

inline int clamp8(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }
} // namespace

BlockCore::BlockCore() { reset(0x1234u); }

// xorshift32（uint32 の剰余演算は JS の >>> と同じ結果になる＝決定的）
uint32_t BlockCore::rng() {
    uint32_t x = rngState_;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    rngState_ = x;
    return x;
}

void BlockCore::reset(uint32_t seed) {
    rngState_ = seed ? seed : 1;
    grid_.fill(0);
    for (int i = 0; i < 8; i++) scores_[i] = 0;
    color_ = 3;
    gameOver_ = false;
    dasTimer_ = 0;
    fallTimer_ = 0;
    riseProgress_ = 0;
    gapCol_ = COLS / 2;

    phase_ = PLAY;
    animTimer_ = 0;
    clearRow_ = -1;
    cascadeCount_ = 0;
    falling_.clear();
    fallDisp_ = 0;
    fallMax_ = 0;
    fallSpeed_ = FALL_SPEED;
    hasPiece_ = false;

    // 開始時の地形: 上から下へ SEED_ROWS 行ぶん積む（つながった蛇行の道つき）
    for (int r = ROWS - SEED_ROWS; r <= ROWS - 1; r++) {
        Span sp = nextGapSpan();
        fillRow(r, sp.lo, sp.hi);
    }
    makeIncoming();
    spawnPiece();
}

// 溝(道)の次の行の空き範囲。前の頭から新しい頭までを空け、4連結の道にする。
BlockCore::Span BlockCore::nextGapSpan() {
    int prev = gapCol_;
    int s = rng() % 4;                                   // 0:左 / 3:右 / 1,2:直進
    int next = prev + (s == 0 ? -1 : (s == 3 ? 1 : 0));
    if (next < 0) next = 0;
    if (next >= COLS) next = COLS - 1;
    gapCol_ = next;
    return { std::min(prev, next), std::max(prev, next) };
}

void BlockCore::fillRow(int r, int lo, int hi) {
    int base = r * COLS;
    for (int c = 0; c < COLS; c++) grid_[base + c] = (c >= lo && c <= hi) ? 0 : 1;
}

void BlockCore::makeIncoming() {
    Span sp = nextGapSpan();
    for (int c = 0; c < COLS; c++) incoming_[c] = (c >= sp.lo && c <= sp.hi) ? 0 : 1;
}

void BlockCore::spawnPiece() {
    int id = rng() % 7;
    for (int i = 0; i < 4; i++) { piece_.cells[i][0] = SHAPES[id][i][0]; piece_.cells[i][1] = SHAPES[id][i][1]; }
    piece_.col = (COLS - 4) / 2;
    piece_.row = -2;
    hasPiece_ = true;
    fallTimer_ = 0;
    if (collides(piece_.col, piece_.row, piece_.cells)) gameOver_ = true;
}

bool BlockCore::collides(int col, int row, const int cells[4][2]) const {
    for (int i = 0; i < 4; i++) {
        int c = col + cells[i][0], r = row + cells[i][1];
        if (c < 0 || c >= COLS) return true;            // 左右の壁
        if (r >= ROWS) return true;                     // 床
        if (r >= 0 && grid_[r * COLS + c] != 0) return true;
    }
    return false;
}

// 着地したピースをバラし各タイルの落下先を計算（真下の空きを順に下りる）。
// out に {col,src,dst} を入れ、最大落下距離を返す。列が満杯なら gameOver_ にして -1。
int BlockCore::computePieceFall(std::vector<FallBlock>& out) {
    struct T { int c, r; };
    std::vector<T> tiles;
    for (int i = 0; i < 4; i++) {
        int c = piece_.col + piece_.cells[i][0], r = piece_.row + piece_.cells[i][1];
        if (c >= 0 && c < COLS) tiles.push_back({ c, r });
    }
    std::sort(tiles.begin(), tiles.end(), [](const T& a, const T& b) { return a.r > b.r; });

    out.clear();
    int maxDist = 0;
    for (const T& t : tiles) {
        int land = t.r;
        while (land + 1 < ROWS && (land + 1 < 0 || grid_[(land + 1) * COLS + t.c] == 0)) land++;
        if (land < 0) { gameOver_ = true; return -1; }
        out.push_back({ t.c, t.r, land });
        grid_[land * COLS + t.c] = 1;                   // 後続タイルが上に積めるよう仮置き
        if (land - t.r > maxDist) maxDist = land - t.r;
    }
    for (const FallBlock& f : out) grid_[f.dst * COLS + f.col] = 0; // 仮置きを戻す
    return maxDist;
}

void BlockCore::detectFullRows(std::vector<int>& out) const {
    out.clear();
    for (int r = 0; r < ROWS; r++) {
        bool full = true;
        for (int c = 0; c < COLS; c++) if (grid_[r * COLS + c] == 0) { full = false; break; }
        if (full) out.push_back(r);
    }
}

void BlockCore::lockPiece() {
    std::vector<FallBlock> res;
    int maxDist = computePieceFall(res);
    if (gameOver_) return;
    hasPiece_ = false;
    cascadeCount_ = 0;
    if (maxDist == 0) {                                 // 落ちない → その場で確定し消去判定へ
        for (const FallBlock& f : res) grid_[f.dst * COLS + f.col] = 1;
        beginClearStep();
    } else {                                            // 割れて下に落ちる動きをアニメ
        falling_ = res;
        fallDisp_ = 0;
        fallMax_ = maxDist;
        fallSpeed_ = PIECE_FALL_SPEED;
        phase_ = FALLING;
    }
}

void BlockCore::beginClearStep() {
    std::vector<int> full;
    detectFullRows(full);
    if (full.empty()) { finishCascade(); return; }
    clearRow_ = full.back();                            // 一番下(最大index)の満杯行
    phase_ = CLEARING;
    animTimer_ = 0;
    hasPiece_ = false;
}

// フラッシュ終了 → その1行を消し、「消えた行より上」だけ重力で落とす（下の壁は固定）
void BlockCore::startFalling() {
    int cr = clearRow_;
    for (int c = 0; c < COLS; c++) grid_[cr * COLS + c] = 0;
    cascadeCount_++;

    falling_.clear();
    int maxDist = 0;
    for (int c = 0; c < COLS; c++) {
        int base = ROWS;                                // この列の固定壁(cr より下)の一番上＝土台
        for (int r = cr + 1; r < ROWS; r++) { if (grid_[r * COLS + c] != 0) { base = r; break; } }
        int wp = base - 1;
        for (int r = cr - 1; r >= 0; r--) {
            if (grid_[r * COLS + c] != 0) {
                if (wp != r) {
                    falling_.push_back({ c, r, wp });
                    grid_[r * COLS + c] = 0;
                    if (wp - r > maxDist) maxDist = wp - r;
                }
                wp--;
            }
        }
    }
    fallDisp_ = 0;
    fallMax_ = maxDist;
    fallSpeed_ = FALL_SPEED;
    phase_ = FALLING;
    if (maxDist == 0) commitFalling();
}

void BlockCore::commitFalling() {
    for (const FallBlock& f : falling_) grid_[f.dst * COLS + f.col] = 1;
    falling_.clear();
    beginClearStep();                                   // 再判定: まだ満杯行があれば次の1行へ
}

void BlockCore::finishCascade() {
    if (cascadeCount_ > 0) {
        scores_[color_] += cascadeCount_ * COLS;
        color_ = (color_ % 7) + 1;                      // 消すと色が変わる
    }
    phase_ = PLAY;
    spawnPiece();
}

void BlockCore::riseOneRow() {
    for (int c = 0; c < COLS; c++) if (grid_[c] != 0) { gameOver_ = true; return; } // 上端あふれ=負け
    std::memmove(&grid_[0], &grid_[COLS], (size_t)(COLS * (ROWS - 1)) * sizeof(uint8_t));
    int base = (ROWS - 1) * COLS;
    for (int c = 0; c < COLS; c++) grid_[base + c] = incoming_[c];
    makeIncoming();
    if (hasPiece_) {
        piece_.row--;
        while (collides(piece_.col, piece_.row, piece_.cells)) piece_.row--;
    }
}

void BlockCore::tick(unsigned input) {
    if (gameOver_) return;

    // 消去アニメ中は通常操作・せり上がりを止めてアニメだけ進める
    if (phase_ == CLEARING) {
        if (++animTimer_ >= CLEAR_FRAMES) startFalling();
        return;
    }
    if (phase_ == FALLING) {
        fallDisp_ += fallSpeed_;
        if (fallDisp_ >= fallMax_) commitFalling();
        return;
    }

    // --- せり上がり ---
    riseProgress_ += RISE_RATE;
    while (riseProgress_ >= 1.0) {
        riseProgress_ -= 1.0;
        riseOneRow();
        if (gameOver_) return;
    }

    // --- 横移動 (DAS/ARR) ---
    int dir = (input & IN_LEFT) ? -1 : ((input & IN_RIGHT) ? 1 : 0);
    if (dir == 0) {
        dasTimer_ = 0;
    } else {
        bool step = (dasTimer_ == 0) ||
                    (dasTimer_ >= DAS && (dasTimer_ - DAS) % ARR == 0);
        dasTimer_++;
        if (step && !collides(piece_.col + dir, piece_.row, piece_.cells)) piece_.col += dir;
    }

    // --- 回転（押した瞬間。frontend がエッジ化して渡す） ---
    if (input & IN_ROT) {
        int rc[4][2];
        for (int i = 0; i < 4; i++) { rc[i][0] = 3 - piece_.cells[i][1]; rc[i][1] = piece_.cells[i][0]; }
        const int kicks[5] = { 0, -1, 1, -2, 2 };
        for (int k = 0; k < 5; k++) {
            if (!collides(piece_.col + kicks[k], piece_.row, rc)) {
                std::memcpy(piece_.cells, rc, sizeof(rc));
                piece_.col += kicks[k];
                break;
            }
        }
    }

    // --- ハードドロップ ---
    if (input & IN_HARD) {
        while (!collides(piece_.col, piece_.row + 1, piece_.cells)) piece_.row++;
        lockPiece();
        return;
    }

    // --- 重力 / ソフトドロップ ---
    fallTimer_++;
    int interval = (input & IN_SOFT) ? SOFT_FRAMES : FALL_FRAMES;
    if (fallTimer_ >= interval) {
        fallTimer_ = 0;
        if (collides(piece_.col, piece_.row + 1, piece_.cells)) lockPiece();
        else piece_.row++;
    }
}

// ----------------- 描画 -----------------
void BlockCore::px(int x, int y, int r, int g, int b) {
    if (x < 0 || x >= FB_W || y < 0 || y >= FB_H) return;
    fb_[y * FB_W + x] = (uint32_t(clamp8(r)) << 16) | (uint32_t(clamp8(g)) << 8) | uint32_t(clamp8(b));
}

// 1タイルを面取り(3D風) + 右下1pxの隙間(グリッド線)で描く
void BlockCore::fillCell(int sx, int sy, int br, int bg, int bb) {
    for (int dy = 0; dy < CELL; dy++) {
        int y = sy + dy;
        if (y < HEADER_H || y >= FB_H) continue;        // ヘッダー領域・画面外は描かない
        if (dy == CELL - 1) continue;                   // 下端1pxは隙間
        for (int dx = 0; dx < CELL; dx++) {
            if (dx == CELL - 1) continue;               // 右端1pxは隙間
            int r = br, g = bg, b = bb;
            if (dy == 0 || dx == 0)                 { r += 45; g += 45; b += 45; } // 左上ハイライト
            else if (dy == CELL - 2 || dx == CELL - 2) { r -= 45; g -= 45; b -= 45; } // 右下シャドウ
            px(sx + dx, y, r, g, b);
        }
    }
}

void BlockCore::render() {
    // 背景
    for (int i = 0; i < FB_W * FB_H; i++) fb_[i] = (16u << 16) | (20u << 8) | 44u;

    // ヘッダー（青帯 + 7色スウォッチ）
    for (int y = 0; y < HEADER_H; y++)
        for (int x = 0; x < FB_W; x++) fb_[y * FB_W + x] = (70u << 16) | (110u << 8) | 210u;
    const int sw = 14;
    const double gap = (FB_W - 7.0 * sw) / 8.0;
    for (int ci = 1; ci <= 7; ci++) {
        int sx = (int)std::lround(gap * ci + sw * (ci - 1));
        for (int y = 3; y < 3 + sw; y++)
            for (int x = sx; x < sx + sw && x < FB_W; x++) px(x, y, COLORS[ci][0], COLORS[ci][1], COLORS[ci][2]);
    }

    const int* col = COLORS[color_];
    const int off = (int)(riseProgress_ * CELL);
    const bool flashOn = (phase_ == CLEARING) && ((animTimer_ / 4) % 2 == 0);

    // 盤面（全ブロックは現在の色）
    for (int r = 0; r <= ROWS; r++) {
        int baseY = HEADER_H + r * CELL - off;
        for (int c = 0; c < COLS; c++) {
            int filled = (r < ROWS) ? grid_[r * COLS + c] : incoming_[c];
            if (!filled) continue;
            bool isFlash = flashOn && r == clearRow_;
            if (isFlash) fillCell(c * CELL, baseY, 255, 255, 255);
            else         fillCell(c * CELL, baseY, col[0], col[1], col[2]);
        }
    }

    // 落下アニメ中のブロック
    if (phase_ == FALLING) {
        for (const FallBlock& f : falling_) {
            double rr = std::min((double)f.dst, (double)f.src + fallDisp_);
            int y = HEADER_H + (int)std::lround(rr * CELL) - off;
            fillCell(f.col * CELL, y, col[0], col[1], col[2]);
        }
    }

    // 落下中のピース
    if (phase_ == PLAY && hasPiece_ && !gameOver_) {
        for (int i = 0; i < 4; i++) {
            int gx = (piece_.col + piece_.cells[i][0]) * CELL;
            int gy = HEADER_H + (piece_.row + piece_.cells[i][1]) * CELL - off;
            fillCell(gx, gy, col[0], col[1], col[2]);
        }
    }
}
