// ============================================================================
// BlockCore — ゲームのロジック + フレームバッファ描画（C++版）
//
// HTMLプロトタイプ(index.html)の BlockCore を移植したもの。
// プラットフォーム非依存: ウィンドウ/入力/音に一切依存しない。
//   - tick(input) : 1フレーム進める（libretro の retro_run() に対応）
//   - render()    : framebuffer(XRGB8888) に画面を描く（video_refresh で渡す）
//   - input は IN_LEFT/RIGHT/ROT/SOFT/HARD のビットマスク（ゲームパッドのボタン）
//   - 乱数はシード付き xorshift32（JS版と同じ結果を再現）
// ============================================================================
#pragma once
#include <cstdint>
#include <array>
#include <vector>

class BlockCore {
public:
    static constexpr int HEADER_H = 20;            // 上部スコアバーの高さ(px)
    static constexpr int CELL     = 12;            // タイル1枚の表示サイズ(px)
    static constexpr int COLS     = 15;            // 横のセル数
    static constexpr int ROWS     = 25;            // 縦のセル数（プレイ領域）
    static constexpr int FB_W     = COLS * CELL;             // 180
    static constexpr int FB_H     = HEADER_H + ROWS * CELL;  // 320

    enum InputBits { IN_LEFT = 1, IN_RIGHT = 2, IN_ROT = 4, IN_SOFT = 8, IN_HARD = 16 };

    BlockCore();
    void reset(uint32_t seed);
    void tick(unsigned input);
    void render();

    const uint32_t* framebuffer() const { return fb_.data(); }   // XRGB8888, FB_W*FB_H
    int  score(int colorIdx) const { return scores_[colorIdx]; }
    int  totalScore() const { int s = 0; for (int i = 1; i < 8; i++) s += scores_[i]; return s; }
    int  currentColor() const { return color_; }
    bool isGameOver() const { return gameOver_; }

private:
    // --- 調整パラメータ（index.html と同じ） ---
    int    FALL_FRAMES      = 16;   // 通常落下: 何フレームで1セル落ちるか
    int    SOFT_FRAMES      = 2;    // ソフトドロップ
    int    DAS              = 8;    // 横移動の初動ディレイ
    int    ARR              = 3;    // 横移動のリピート間隔
    double RISE_RATE        = 0.015;// せり上がり(セル/フレーム)
    int    SEED_ROWS        = 8;    // 開始時に積んでおく行数
    int    CLEAR_FRAMES     = 24;   // 消える列のフラッシュ時間
    double FALL_SPEED       = 0.2;  // クリア時の落下速度(マス/フレーム)
    double PIECE_FALL_SPEED = 0.2;  // ピースが割れて落ちる速度

    struct Span      { int lo, hi; };
    struct FallBlock { int col, src, dst; };
    struct Piece     { int cells[4][2]; int col, row; };
    enum   Phase     { PLAY, CLEARING, FALLING };

    std::array<uint32_t, FB_W * FB_H> fb_{};
    std::array<uint8_t,  COLS * ROWS> grid_{};   // 0=空 / 1=ブロック（色は共通 color_）
    std::array<uint8_t,  COLS>        incoming_{};

    uint32_t rngState_ = 1;
    int      scores_[8] = {0};
    int      color_     = 3;
    bool     gameOver_  = false;
    int      dasTimer_  = 0;
    int      fallTimer_ = 0;
    double   riseProgress_ = 0;
    int      gapCol_    = COLS / 2;

    Phase    phase_      = PLAY;
    int      animTimer_  = 0;
    int      clearRow_   = -1;
    int      cascadeCount_ = 0;
    std::vector<FallBlock> falling_;
    double   fallDisp_   = 0;
    int      fallMax_    = 0;
    double   fallSpeed_  = 0.2;

    Piece    piece_{};
    bool     hasPiece_   = false;

    uint32_t rng();
    Span     nextGapSpan();
    void     fillRow(int r, int lo, int hi);
    void     makeIncoming();
    void     spawnPiece();
    bool     collides(int col, int row, const int cells[4][2]) const;
    int      computePieceFall(std::vector<FallBlock>& out);
    void     detectFullRows(std::vector<int>& out) const;
    void     lockPiece();
    void     beginClearStep();
    void     startFalling();
    void     commitFalling();
    void     finishCascade();
    void     riseOneRow();
    void     px(int x, int y, int r, int g, int b);
    void     fillCell(int sx, int sy, int r, int g, int b);
};
