# ============================================================================
# フェーズ3: Emscripten(WASM) ビルド
#   blockcore.cpp + libretro_core.cpp + emscripten_main.cpp を emcc でビルドし、
#   web/index.html (+ .js / .wasm) を生成する。
#
# 使い方（PowerShell）:
#   .\build_wasm.ps1            # ビルドのみ
#   .\build_wasm.ps1 -Serve     # ビルド後にローカルサーバを起動
# ============================================================================
param([switch]$Serve)

$ErrorActionPreference = 'Stop'
$here   = $PSScriptRoot
$emBin  = 'C:\prog\emsdk\emsdk\upstream\emscripten'
$emcc   = Join-Path $emBin 'emcc.exe'
$emrun  = Join-Path $emBin 'emrun.exe'
$outDir = Join-Path $here 'web'

if (-not (Test-Path $emcc))   { throw "emcc.exe が見つかりません: $emcc" }
if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir | Out-Null }

$srcs = @('blockcore.cpp', 'libretro_core.cpp', 'emscripten_main.cpp') | ForEach-Object { Join-Path $here $_ }

$args = @(
  '-O2', '-std=c++17',
  '-I', $here,
  '-s', 'WASM=1',
  '-s', 'ENVIRONMENT=web',
  '--shell-file', (Join-Path $here 'shell.html'),
  '-o', (Join-Path $outDir 'index.html')
) + $srcs

Write-Host "$emcc $($args -join ' ')" -ForegroundColor DarkGray
& $emcc @args
Write-Host "OK -> $outDir\index.html" -ForegroundColor Green

if ($Serve) {
  Write-Host 'http://localhost:8000/  (Ctrl+C で停止)' -ForegroundColor Cyan
  & $emrun --no_browser --port 8000 (Join-Path $outDir 'index.html')
}
