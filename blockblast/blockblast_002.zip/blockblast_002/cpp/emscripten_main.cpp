// ============================================================================
// Emscripten(WASM) フロントエンド（フェーズ3）
//   Win32 版(win32_main.cpp)と同じく libretro API(retro_*) を叩いてコアを動かし、
//   framebuffer(XRGB8888) を <canvas> に描画する。
//   操作: ← → 移動 / ↑ 回転 / ↓ ソフトドロップ / Space ハードドロップ / R リスタート
// ============================================================================
#include <emscripten.h>
#include <emscripten/html5.h>
#include <cstdint>
#include <cstring>
#include "libretro.h"
#include "blockcore.h"   // FB_W / FB_H 定数用

static const int SCALE = 2;   // 表示倍率

static const uint32_t* g_fb  = nullptr;
static unsigned        g_fbw = 0, g_fbh = 0;

// 論理キー（Win32 版のキー割り当てに対応）
enum LKey { LK_LEFT, LK_RIGHT, LK_UP /*回転*/, LK_DOWN /*ソフト*/, LK_HARD /*Space*/, LK_COUNT };
static bool g_keys[LK_COUNT] = { false };

// XRGB8888 -> RGBA 変換先（canvas ImageData 用）
static uint8_t g_rgba[BlockCore::FB_W * BlockCore::FB_H * 4];

// ---- libretro コールバック（win32_main.cpp と同じ）----
static void   cb_video(const void* data, unsigned w, unsigned h, size_t /*pitch*/) {
    g_fb = (const uint32_t*)data; g_fbw = w; g_fbh = h;
}
static void   cb_audio_sample(int16_t, int16_t) {}
static size_t cb_audio_batch(const int16_t*, size_t frames) { return frames; }
static void   cb_input_poll(void) {}

static int16_t cb_input_state(unsigned port, unsigned device, unsigned, unsigned id) {
    if (port != 0 || device != RETRO_DEVICE_JOYPAD) return 0;
    switch (id) {
        case RETRO_DEVICE_ID_JOYPAD_LEFT:  return g_keys[LK_LEFT]  ? 1 : 0;
        case RETRO_DEVICE_ID_JOYPAD_RIGHT: return g_keys[LK_RIGHT] ? 1 : 0;
        case RETRO_DEVICE_ID_JOYPAD_DOWN:  return g_keys[LK_DOWN]  ? 1 : 0;
        case RETRO_DEVICE_ID_JOYPAD_UP:    return g_keys[LK_UP]    ? 1 : 0; // 回転
        case RETRO_DEVICE_ID_JOYPAD_A:     return g_keys[LK_UP]    ? 1 : 0; // 回転(別割当)
        case RETRO_DEVICE_ID_JOYPAD_B:     return g_keys[LK_HARD]  ? 1 : 0; // ハードドロップ
        default: return 0;
    }
}

static bool cb_environment(unsigned cmd, void* data) {
    switch (cmd) {
        case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: {
            const enum retro_pixel_format* fmt = (const enum retro_pixel_format*)data;
            return *fmt == RETRO_PIXEL_FORMAT_XRGB8888;
        }
        case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
            return true;
        default:
            return false;
    }
}

// ---- canvas 操作（JS 側）----
EM_JS(void, js_init_canvas, (int w, int h, int scale), {
    var c = Module['canvas'] || document.getElementById('canvas');
    c.width = w; c.height = h;
    c.style.width  = (w * scale) + 'px';
    c.style.height = (h * scale) + 'px';
    c.style.imageRendering = 'pixelated';
    Module['canvas'] = c;
});

EM_JS(void, js_blit, (const uint8_t* ptr, int w, int h), {
    var c = Module['canvas'] || document.getElementById('canvas');
    var ctx = c.getContext('2d');
    var img = ctx.createImageData(w, h);
    img.data.set(HEAPU8.subarray(ptr, ptr + w * h * 4));
    ctx.putImageData(img, 0, 0);
});

// ---- キーボード（code 文字列で判定。keyCode は非推奨のため使わない）----
static int codeToLKey(const char* code) {
    if (!std::strcmp(code, "ArrowLeft"))  return LK_LEFT;
    if (!std::strcmp(code, "ArrowRight")) return LK_RIGHT;
    if (!std::strcmp(code, "ArrowUp"))    return LK_UP;
    if (!std::strcmp(code, "ArrowDown"))  return LK_DOWN;
    if (!std::strcmp(code, "Space"))      return LK_HARD;
    return -1;
}

static EM_BOOL on_key(int eventType, const EmscriptenKeyboardEvent* e, void*) {
    bool down = (eventType == EMSCRIPTEN_EVENT_KEYDOWN);
    int lk = codeToLKey(e->code);
    if (lk >= 0) { g_keys[lk] = down; return EM_TRUE; }   // 矢印/Space のスクロールを止める
    if (down && (!std::strcmp(e->code, "KeyR"))) retro_reset();
    return EM_FALSE;
}

// ---- 1フレーム（requestAnimationFrame 駆動）----
static void frame() {
    retro_run();                 // tick + render → cb_video が g_fb を更新
    if (!g_fb) return;
    int n = (int)(g_fbw * g_fbh);
    for (int i = 0; i < n; i++) {
        uint32_t p = g_fb[i];                 // 0x00RRGGBB
        g_rgba[i * 4 + 0] = (p >> 16) & 0xff; // R
        g_rgba[i * 4 + 1] = (p >>  8) & 0xff; // G
        g_rgba[i * 4 + 2] =  p        & 0xff; // B
        g_rgba[i * 4 + 3] = 255;              // A
    }
    js_blit(g_rgba, (int)g_fbw, (int)g_fbh);
}

int main() {
    retro_set_environment(cb_environment);
    retro_set_video_refresh(cb_video);
    retro_set_audio_sample(cb_audio_sample);
    retro_set_audio_sample_batch(cb_audio_batch);
    retro_set_input_poll(cb_input_poll);
    retro_set_input_state(cb_input_state);
    retro_init();
    retro_load_game(nullptr);

    retro_system_av_info av; retro_get_system_av_info(&av);
    js_init_canvas((int)av.geometry.base_width, (int)av.geometry.base_height, SCALE);

    emscripten_set_keydown_callback(EMSCRIPTEN_EVENT_TARGET_WINDOW, nullptr, EM_TRUE, on_key);
    emscripten_set_keyup_callback(  EMSCRIPTEN_EVENT_TARGET_WINDOW, nullptr, EM_TRUE, on_key);

    emscripten_set_main_loop(frame, 0, 1);   // fps=0 → requestAnimationFrame(≒60fps)
    return 0;
}
