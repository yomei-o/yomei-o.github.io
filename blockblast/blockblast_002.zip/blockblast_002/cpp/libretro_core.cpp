// BlockCore を libretro API でラップする実装
#include "libretro.h"
#include "blockcore.h"
#include <cstring>

static BlockCore                  g_core;
static retro_environment_t        env_cb         = nullptr;
static retro_video_refresh_t      video_cb       = nullptr;
static retro_audio_sample_t       audio_cb       = nullptr;
static retro_audio_sample_batch_t audio_batch_cb = nullptr;
static retro_input_poll_t         input_poll_cb  = nullptr;
static retro_input_state_t        input_state_cb = nullptr;

RETRO_API void retro_set_environment(retro_environment_t cb) {
    env_cb = cb;
    bool no_game = true;                                // コンテンツ不要のコア
    if (cb) cb(RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME, &no_game);
}
RETRO_API void retro_set_video_refresh(retro_video_refresh_t cb)        { video_cb = cb; }
RETRO_API void retro_set_audio_sample(retro_audio_sample_t cb)          { audio_cb = cb; }
RETRO_API void retro_set_audio_sample_batch(retro_audio_sample_batch_t cb) { audio_batch_cb = cb; }
RETRO_API void retro_set_input_poll(retro_input_poll_t cb)             { input_poll_cb = cb; }
RETRO_API void retro_set_input_state(retro_input_state_t cb)           { input_state_cb = cb; }

RETRO_API void     retro_init(void)        {}
RETRO_API void     retro_deinit(void)      {}
RETRO_API unsigned retro_api_version(void) { return RETRO_API_VERSION; }

RETRO_API void retro_get_system_info(struct retro_system_info* info) {
    std::memset(info, 0, sizeof(*info));
    info->library_name    = "BlockBlast";
    info->library_version = "0.1";
    info->valid_extensions = "";
    info->need_fullpath   = false;
    info->block_extract   = false;
}

RETRO_API void retro_get_system_av_info(struct retro_system_av_info* info) {
    info->geometry.base_width   = BlockCore::FB_W;
    info->geometry.base_height  = BlockCore::FB_H;
    info->geometry.max_width    = BlockCore::FB_W;
    info->geometry.max_height   = BlockCore::FB_H;
    info->geometry.aspect_ratio = (float)BlockCore::FB_W / (float)BlockCore::FB_H;
    info->timing.fps            = 60.0;
    info->timing.sample_rate    = 44100.0;
}

RETRO_API void retro_set_controller_port_device(unsigned, unsigned) {}
RETRO_API void retro_reset(void) { g_core.reset(0x1234u); }

// libretro の入力(押下状態)を BlockCore のビットマスクに変換。
// 回転・ハードドロップは「押した瞬間」だけ有効にする（エッジ検出）。
static unsigned poll_input() {
    if (!input_state_cb) return 0;
    auto down = [&](unsigned id) { return input_state_cb(0, RETRO_DEVICE_JOYPAD, 0, id) != 0; };
    unsigned m = 0;
    if (down(RETRO_DEVICE_ID_JOYPAD_LEFT))  m |= BlockCore::IN_LEFT;
    if (down(RETRO_DEVICE_ID_JOYPAD_RIGHT)) m |= BlockCore::IN_RIGHT;
    if (down(RETRO_DEVICE_ID_JOYPAD_DOWN))  m |= BlockCore::IN_SOFT;

    static bool prevRot = false, prevHard = false;
    bool rot  = down(RETRO_DEVICE_ID_JOYPAD_UP) || down(RETRO_DEVICE_ID_JOYPAD_A);
    bool hard = down(RETRO_DEVICE_ID_JOYPAD_B);
    if (rot  && !prevRot)  m |= BlockCore::IN_ROT;
    if (hard && !prevHard) m |= BlockCore::IN_HARD;
    prevRot = rot; prevHard = hard;
    return m;
}

RETRO_API void retro_run(void) {
    if (input_poll_cb) input_poll_cb();
    g_core.tick(poll_input());
    g_core.render();
    if (video_cb)
        video_cb(g_core.framebuffer(), BlockCore::FB_W, BlockCore::FB_H,
                 (size_t)BlockCore::FB_W * sizeof(uint32_t));
    // 無音オーディオ（RetroArch のペース合わせ用。44100/60≒735サンプル）
    if (audio_batch_cb) { static int16_t buf[735 * 2] = {0}; audio_batch_cb(buf, 735); }
}

RETRO_API bool retro_load_game(const struct retro_game_info*) {
    enum retro_pixel_format fmt = RETRO_PIXEL_FORMAT_XRGB8888;
    if (env_cb && !env_cb(RETRO_ENVIRONMENT_SET_PIXEL_FORMAT, &fmt)) return false;
    g_core.reset(0x1234u);
    return true;
}

RETRO_API bool   retro_load_game_special(unsigned, const struct retro_game_info*, size_t) { return false; }
RETRO_API void   retro_unload_game(void)             {}
RETRO_API unsigned retro_get_region(void)            { return 0; }
RETRO_API void*  retro_get_memory_data(unsigned)     { return nullptr; }
RETRO_API size_t retro_get_memory_size(unsigned)     { return 0; }
RETRO_API size_t retro_serialize_size(void)          { return 0; }
RETRO_API bool   retro_serialize(void*, size_t)      { return false; }
RETRO_API bool   retro_unserialize(const void*, size_t) { return false; }
RETRO_API void   retro_cheat_reset(void)             {}
RETRO_API void   retro_cheat_set(unsigned, bool, const char*) {}
