// ============================================================================
// 最小 Win32 フロントエンド
//   libretro API(retro_*) を叩いてコアを動かし、framebuffer をウィンドウへ描画する。
//   操作: ← → 移動 / ↑ 回転 / ↓ ソフトドロップ / Space ハードドロップ / R リスタート / Esc 終了
// ============================================================================
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include "libretro.h"

static const int SCALE = 2;                    // 表示倍率

static const uint32_t* g_fb = nullptr;
static unsigned g_fbw = 0, g_fbh = 0;
static bool     g_keys[256] = { false };
static HWND     g_hwnd = nullptr;

// ---- libretro コールバック ----
static void cb_video(const void* data, unsigned w, unsigned h, size_t /*pitch*/) {
    g_fb = (const uint32_t*)data; g_fbw = w; g_fbh = h;
}
static void   cb_audio_sample(int16_t, int16_t) {}
static size_t cb_audio_batch(const int16_t*, size_t frames) { return frames; }
static void   cb_input_poll(void) {}

static int16_t cb_input_state(unsigned port, unsigned device, unsigned, unsigned id) {
    if (port != 0 || device != RETRO_DEVICE_JOYPAD) return 0;
    switch (id) {
        case RETRO_DEVICE_ID_JOYPAD_LEFT:  return g_keys[VK_LEFT]  ? 1 : 0;
        case RETRO_DEVICE_ID_JOYPAD_RIGHT: return g_keys[VK_RIGHT] ? 1 : 0;
        case RETRO_DEVICE_ID_JOYPAD_DOWN:  return g_keys[VK_DOWN]  ? 1 : 0;
        case RETRO_DEVICE_ID_JOYPAD_UP:    return g_keys[VK_UP]    ? 1 : 0; // 回転
        case RETRO_DEVICE_ID_JOYPAD_A:     return g_keys[VK_UP]    ? 1 : 0; // 回転(別割当)
        case RETRO_DEVICE_ID_JOYPAD_B:     return g_keys[VK_SPACE] ? 1 : 0; // ハードドロップ
        default: return 0;
    }
}

static bool cb_environment(unsigned cmd, void* data) {
    switch (cmd) {
        case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: {
            const enum retro_pixel_format* fmt = (const enum retro_pixel_format*)data;
            return *fmt == RETRO_PIXEL_FORMAT_XRGB8888;   // このフロントエンドは XRGB8888 のみ
        }
        case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
            return true;
        default:
            return false;
    }
}

static void blit() {
    if (!g_fb) return;
    BITMAPINFO bmi; ZeroMemory(&bmi, sizeof(bmi));
    bmi.bmiHeader.biSize        = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth       = (LONG)g_fbw;
    bmi.bmiHeader.biHeight      = -(LONG)g_fbh;          // top-down
    bmi.bmiHeader.biPlanes      = 1;
    bmi.bmiHeader.biBitCount    = 32;                    // XRGB8888 ≒ BGRX を BI_RGB で
    bmi.bmiHeader.biCompression = BI_RGB;

    HDC hdc = GetDC(g_hwnd);
    RECT rc; GetClientRect(g_hwnd, &rc);
    StretchDIBits(hdc, 0, 0, rc.right, rc.bottom, 0, 0, (int)g_fbw, (int)g_fbh,
                  g_fb, &bmi, DIB_RGB_COLORS, SRCCOPY);
    ReleaseDC(g_hwnd, hdc);
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_KEYDOWN:
            if (wp < 256) g_keys[wp] = true;
            if (wp == VK_ESCAPE) PostQuitMessage(0);
            if (wp == 'R')       retro_reset();
            return 0;
        case WM_KEYUP:
            if (wp < 256) g_keys[wp] = false;
            return 0;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        default:
            return DefWindowProc(hwnd, msg, wp, lp);
    }
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nShow) {
    // コアにコールバックを登録して起動
    retro_set_environment(cb_environment);
    retro_set_video_refresh(cb_video);
    retro_set_audio_sample(cb_audio_sample);
    retro_set_audio_sample_batch(cb_audio_batch);
    retro_set_input_poll(cb_input_poll);
    retro_set_input_state(cb_input_state);
    retro_init();
    retro_load_game(nullptr);

    retro_system_av_info av; retro_get_system_av_info(&av);
    int cw = (int)av.geometry.base_width  * SCALE;
    int ch = (int)av.geometry.base_height * SCALE;

    WNDCLASS wc = {};
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInst;
    wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    wc.lpszClassName = "BlockBlastWnd";
    RegisterClass(&wc);

    DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX; // サイズ変更不可
    RECT wr = { 0, 0, cw, ch };
    AdjustWindowRect(&wr, style, FALSE);
    g_hwnd = CreateWindow("BlockBlastWnd", "Block Blast (libretro core)", style,
                          CW_USEDEFAULT, CW_USEDEFAULT, wr.right - wr.left, wr.bottom - wr.top,
                          nullptr, nullptr, hInst, nullptr);
    ShowWindow(g_hwnd, nShow);

    // 60fps ループ
    LARGE_INTEGER freq, prev; QueryPerformanceFrequency(&freq); QueryPerformanceCounter(&prev);
    const double frameSec = 1.0 / 60.0;
    bool running = true;
    while (running) {
        MSG msg;
        while (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) running = false;
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        if (!running) break;

        LARGE_INTEGER now; QueryPerformanceCounter(&now);
        double elapsed = double(now.QuadPart - prev.QuadPart) / double(freq.QuadPart);
        if (elapsed < frameSec) { Sleep(1); continue; }
        prev = now;

        retro_run();
        blit();
    }

    retro_unload_game();
    retro_deinit();
    return 0;
}
